Project Name: Raspberry Pi Parcel Defect Detection Camera System
Project Version: #ce9d7e20
Project Url: https://www.flux.ai/hafizkwar3/raspberry-pi-parcel-defect-detection-camera-system~wl

Project Description:
Raspberry Pi 5 parcel defect detection camera system with 12V protected power input, 5.1V Raspberry Pi supply, isolated photoelectric trigger input, PWM LED lighting control, pass/defect indicators, and relay/PLC ejector output.


